package ru.itschool.myapplication;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import ru.itschool.myapplication.databinding.ActivityFinishBinding;

public class FinishActivity extends AppCompatActivity {
    private  static  final  String GALLERY_COUNT="galleryCount";
    private float sum = 0;
    private float  Totalsum = 6;
    private float result = 0;

    private  static  final  String NUMBER1 = "number1";
    private  static  final  String NUMBER2 = "number2";
    private  static  final  String NUMBER3 = "number3";
    private  static  final  String NUMBER4 = "number4";
    private  static  final  String NUMBER5 = "number5";
    private  static  final  String NUMBER6 = "number6";

    private  static  final  String CAMERA_COUNT="cameraCount";
    private  static  final  String MANAGE_COUNT="manageCount";
    private  static  final  String SHARE_COUNT="shareCount";
    private  static  final  String CALL_COUNT="callCount";
    private  static  final  String COMPASSCOUNT="compassCount";
    private ActivityFinishBinding binding;
    private TextView sumTextView;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_finish);

        sumTextView = findViewById(R.id.sumTextView);




        binding = ActivityFinishBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());
        int galleryCount = getIntent().getIntExtra(GALLERY_COUNT, 0);
        int  manageCount = getIntent().getIntExtra(MANAGE_COUNT, 0);
        int shareCount  = getIntent().getIntExtra(SHARE_COUNT, 0);
        int callCount = getIntent().getIntExtra(CALL_COUNT, 0);
        int compassCount = getIntent().getIntExtra(COMPASSCOUNT, 0);
        int cameraCount = getIntent().getIntExtra(CAMERA_COUNT, 0);



        int number1 = getIntent().getIntExtra(NUMBER1, 0);
        int number2 = getIntent().getIntExtra(NUMBER2, 0);
        int number3 = getIntent().getIntExtra(NUMBER3, 0);
        int number4 = getIntent().getIntExtra(NUMBER4, 0);
        int number5 = getIntent().getIntExtra(NUMBER5, 0);
        int number6 = getIntent().getIntExtra(NUMBER6, 0);
        calculateSum(galleryCount, cameraCount, manageCount, shareCount, callCount, compassCount, number1, number2, number3, number4, number5, number6);

        Total_Sum(galleryCount, cameraCount, manageCount, shareCount, callCount, compassCount);
        binding.sumTextView.setText(Float.toString(result) + "%");


        binding.toMainActivity.setOnClickListener(v -> {
            Intent intent = new Intent(FinishActivity.this, MainActivity.class);

            startActivity(intent);

            finish();
        });
    }
    public  static  Intent getIntent(Context context, int galleryCount, int cameraCount, int manageCount, int shareCount, int callCount, int compassCount, int number1, int number2, int number3, int number4, int number5, int number6){
        Intent intent = new Intent(context,FinishActivity.class);
        intent.putExtra(GALLERY_COUNT,galleryCount);
        intent.putExtra(MANAGE_COUNT,manageCount);
        intent.putExtra(COMPASSCOUNT,compassCount);
        intent.putExtra(CALL_COUNT,callCount);
        intent.putExtra(CAMERA_COUNT,cameraCount);
        intent.putExtra(SHARE_COUNT,shareCount);
        intent.putExtra(NUMBER1,number1);
        intent.putExtra(NUMBER2,number2);
        intent.putExtra(NUMBER3,number3);
        intent.putExtra(NUMBER4,number4);
        intent.putExtra(NUMBER5,number5);
        intent.putExtra(NUMBER6,number6);
        return  intent;
    }
    private void calculateSum(int galleryCount,int cameraCount,int  manageCount, int shareCount,int callCount, int compassCount,int number1, int number2, int number3, int number4, int number5, int number6) {
        if (galleryCount == number1) {
            sum++;
        }
        if (cameraCount == number2) {
            sum++;
        }
        if (manageCount == number3) {
            sum++;
        }
        if (shareCount == number4) {
            sum++;
        }
        if (callCount == number5) {
            sum++;
        }
        if (compassCount == number6) {
            sum++;
        }
        System.out.println("galleryCount "+galleryCount);
        System.out.println("cameraCount "+cameraCount);
        System.out.println("manageCount "+manageCount);
        System.out.println("shareCount "+shareCount);
        System.out.println("callCount "+callCount);
        System.out.println("compassCount "+compassCount);

        System.out.println(sum);


    }
    private  void Total_Sum(int galleryCount,int cameraCount,int  manageCount, int shareCount,int callCount, int compassCount){


        result = Math.round((sum / Totalsum) * 100);

        System.out.println("Total Sum "+ Totalsum);
        System.out.println("result "+ result+"%");
    }




}

